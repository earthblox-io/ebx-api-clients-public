# Copyright (c) 2026 Quosient Ltd.
# SPDX-License-Identifier: MIT

#' @title ClientConfig
#' @description R6 class for Earth Blox API client configuration
#' @importFrom R6 R6Class
#' @export
ClientConfig <- R6::R6Class(
  "ClientConfig",
  public = list(
    #' @field base_url The base URL for the API
    base_url = NULL,
    
    #' @field api_prefix The version prefix for the API
    api_prefix = NULL,
    
    #' @field oauth_path The path for the OAuth flow
    oauth_path = NULL,
    
    #' @field persistence_driver The persistence driver for storing credentials
    persistence_driver = NULL,
    
    #' @description Create a new ClientConfig object
    #' @param persistence_driver Optional persistence driver to use for storing
    #'   credentials. If NULL (default), a \code{LocalFilePersistence} writing
    #'   to a sub-directory of \code{tempdir()} is used. Pass a
    #'   \code{MemoryPersistence} instance for hosted environments such as
    #'   shinyapps.io where file persistence might be undesirable.
    #' @return A new ClientConfig object
    initialize = function(persistence_driver = NULL) {
      self$base_url <- BASE_URL
      self$api_prefix <- API_PREFIX
      self$oauth_path <- OAUTH_PATH
      # Credentials are stored under a sub-directory of tempdir() by default,
      # which is always writable and does not touch the user's home filespace.
      # A custom driver (e.g. MemoryPersistence) can be injected via the
      # persistence_driver argument.
      self$persistence_driver <- if (!is.null(persistence_driver)) {
        persistence_driver
      } else {
        LocalFilePersistence$new(path = API_SECRETS_PATH)
      }
      
      # Override with environment variables if set
      emulator_host <- Sys.getenv("EBX_API_EMULATOR_HOST", unset = "")
      if (nchar(emulator_host) > 0) {
        self$base_url <- emulator_host
      }
      
      prefix_path <- Sys.getenv("EBX_API_PREFIX_PATH", unset = "")
      if (nchar(prefix_path) > 0) {
        self$api_prefix <- prefix_path
      }
    },
    
    #' @description Get the full API base URL including version prefix
    #' @return The full API base URL
    get_api_base_url = function() {
      paste0(self$base_url, self$api_prefix)
    },
    
    #' @description Get the OAuth URL
    #' @return The OAuth URL
    get_oauth_url = function() {
      auth_emulator <- Sys.getenv("EBX_API_AUTH_EMULATOR", unset = "")
      if (nchar(auth_emulator) > 0) {
        return(auth_emulator)
      }
      paste0(self$base_url, self$oauth_path)
    },
    
    #' @description Get the persistence driver
    #' @return The persistence driver
    get_persistence_driver = function() {
      self$persistence_driver
    },

    #' @description Set the persistence driver
    #' @param driver A persistence driver object (e.g. \code{LocalFilePersistence}
    #'   or \code{MemoryPersistence})
    #' @return self (invisible)
    set_persistence_driver = function(driver) {
      self$persistence_driver <- driver
      invisible(self)
    }
  )
)

#' @title ServiceClientConfig
#' @description R6 class for Earth Blox API client configuration for service endpoints
#' @importFrom R6 R6Class
#' @export
ServiceClientConfig <- R6::R6Class(
  "ServiceClientConfig",
  inherit = ClientConfig,
  public = list(
    #' @description Create a new ServiceClientConfig object
    #' @param persistence_driver Optional persistence driver (see
    #'   \code{ClientConfig}).
    #' @return A new ServiceClientConfig object
    initialize = function(persistence_driver = NULL) {
      super$initialize(persistence_driver = persistence_driver)
      self$api_prefix <- ""
      self$base_url <- BASE_URL
      
      # Override with environment variable if set
      client_reg <- Sys.getenv("EBX_API_CLIENT_REGISTRATION", unset = "")
      if (nchar(client_reg) > 0) {
        self$base_url <- client_reg
      }
    }
  )
)
